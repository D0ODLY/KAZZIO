﻿namespace KAZZIO
{
    partial class ScriptHub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton9 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton10 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton11 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton12 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton13 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton14 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton15 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton16 = new Guna.UI.WinForms.GunaButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunaButton17 = new Guna.UI.WinForms.GunaButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaButton4
            // 
            this.gunaButton4.Animated = true;
            this.gunaButton4.AnimationHoverSpeed = 0.05F;
            this.gunaButton4.AnimationSpeed = 0.01F;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Black;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton4.ForeColor = System.Drawing.Color.White;
            this.gunaButton4.Image = null;
            this.gunaButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton4.Location = new System.Drawing.Point(22, 74);
            this.gunaButton4.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Size = new System.Drawing.Size(109, 46);
            this.gunaButton4.TabIndex = 7;
            this.gunaButton4.Text = "Clear";
            this.gunaButton4.Click += new System.EventHandler(this.gunaButton4_Click);
            // 
            // gunaButton1
            // 
            this.gunaButton1.Animated = true;
            this.gunaButton1.AnimationHoverSpeed = 0.05F;
            this.gunaButton1.AnimationSpeed = 0.01F;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(22, 128);
            this.gunaButton1.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(109, 46);
            this.gunaButton1.TabIndex = 8;
            this.gunaButton1.Text = "Clear";
            // 
            // gunaButton2
            // 
            this.gunaButton2.Animated = true;
            this.gunaButton2.AnimationHoverSpeed = 0.05F;
            this.gunaButton2.AnimationSpeed = 0.01F;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(276, 74);
            this.gunaButton2.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Size = new System.Drawing.Size(109, 46);
            this.gunaButton2.TabIndex = 9;
            this.gunaButton2.Text = "Clear";
            // 
            // gunaButton3
            // 
            this.gunaButton3.Animated = true;
            this.gunaButton3.AnimationHoverSpeed = 0.05F;
            this.gunaButton3.AnimationSpeed = 0.01F;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton3.ForeColor = System.Drawing.Color.White;
            this.gunaButton3.Image = null;
            this.gunaButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton3.Location = new System.Drawing.Point(150, 74);
            this.gunaButton3.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Size = new System.Drawing.Size(109, 46);
            this.gunaButton3.TabIndex = 10;
            this.gunaButton3.Text = "Clear";
            // 
            // gunaButton5
            // 
            this.gunaButton5.Animated = true;
            this.gunaButton5.AnimationHoverSpeed = 0.05F;
            this.gunaButton5.AnimationSpeed = 0.01F;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.Black;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton5.ForeColor = System.Drawing.Color.White;
            this.gunaButton5.Image = null;
            this.gunaButton5.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton5.Location = new System.Drawing.Point(150, 128);
            this.gunaButton5.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Size = new System.Drawing.Size(109, 46);
            this.gunaButton5.TabIndex = 11;
            this.gunaButton5.Text = "Clear";
            // 
            // gunaButton6
            // 
            this.gunaButton6.Animated = true;
            this.gunaButton6.AnimationHoverSpeed = 0.05F;
            this.gunaButton6.AnimationSpeed = 0.01F;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.Black;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton6.ForeColor = System.Drawing.Color.White;
            this.gunaButton6.Image = null;
            this.gunaButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton6.Location = new System.Drawing.Point(276, 128);
            this.gunaButton6.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Size = new System.Drawing.Size(109, 46);
            this.gunaButton6.TabIndex = 12;
            this.gunaButton6.Text = "Clear";
            // 
            // gunaButton7
            // 
            this.gunaButton7.Animated = true;
            this.gunaButton7.AnimationHoverSpeed = 0.05F;
            this.gunaButton7.AnimationSpeed = 0.01F;
            this.gunaButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton7.BorderColor = System.Drawing.Color.Black;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton7.ForeColor = System.Drawing.Color.White;
            this.gunaButton7.Image = null;
            this.gunaButton7.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton7.Location = new System.Drawing.Point(22, 182);
            this.gunaButton7.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton7.Size = new System.Drawing.Size(109, 46);
            this.gunaButton7.TabIndex = 13;
            this.gunaButton7.Text = "Clear";
            // 
            // gunaButton8
            // 
            this.gunaButton8.Animated = true;
            this.gunaButton8.AnimationHoverSpeed = 0.05F;
            this.gunaButton8.AnimationSpeed = 0.01F;
            this.gunaButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton8.BorderColor = System.Drawing.Color.Black;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton8.ForeColor = System.Drawing.Color.White;
            this.gunaButton8.Image = null;
            this.gunaButton8.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton8.Location = new System.Drawing.Point(150, 182);
            this.gunaButton8.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton8.Size = new System.Drawing.Size(109, 46);
            this.gunaButton8.TabIndex = 14;
            this.gunaButton8.Text = "Clear";
            // 
            // gunaButton9
            // 
            this.gunaButton9.Animated = true;
            this.gunaButton9.AnimationHoverSpeed = 0.05F;
            this.gunaButton9.AnimationSpeed = 0.01F;
            this.gunaButton9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton9.BorderColor = System.Drawing.Color.Black;
            this.gunaButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton9.ForeColor = System.Drawing.Color.White;
            this.gunaButton9.Image = null;
            this.gunaButton9.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton9.Location = new System.Drawing.Point(276, 182);
            this.gunaButton9.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton9.Name = "gunaButton9";
            this.gunaButton9.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton9.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton9.OnHoverImage = null;
            this.gunaButton9.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton9.Size = new System.Drawing.Size(109, 46);
            this.gunaButton9.TabIndex = 15;
            this.gunaButton9.Text = "Clear";
            // 
            // gunaButton10
            // 
            this.gunaButton10.Animated = true;
            this.gunaButton10.AnimationHoverSpeed = 0.05F;
            this.gunaButton10.AnimationSpeed = 0.01F;
            this.gunaButton10.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton10.BorderColor = System.Drawing.Color.Black;
            this.gunaButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton10.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton10.ForeColor = System.Drawing.Color.White;
            this.gunaButton10.Image = null;
            this.gunaButton10.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton10.Location = new System.Drawing.Point(276, 236);
            this.gunaButton10.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton10.Name = "gunaButton10";
            this.gunaButton10.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton10.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton10.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton10.OnHoverImage = null;
            this.gunaButton10.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton10.Size = new System.Drawing.Size(109, 46);
            this.gunaButton10.TabIndex = 16;
            this.gunaButton10.Text = "Clear";
            // 
            // gunaButton11
            // 
            this.gunaButton11.Animated = true;
            this.gunaButton11.AnimationHoverSpeed = 0.05F;
            this.gunaButton11.AnimationSpeed = 0.01F;
            this.gunaButton11.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton11.BorderColor = System.Drawing.Color.Black;
            this.gunaButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton11.ForeColor = System.Drawing.Color.White;
            this.gunaButton11.Image = null;
            this.gunaButton11.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton11.Location = new System.Drawing.Point(150, 236);
            this.gunaButton11.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton11.Name = "gunaButton11";
            this.gunaButton11.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton11.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton11.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton11.OnHoverImage = null;
            this.gunaButton11.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton11.Size = new System.Drawing.Size(109, 46);
            this.gunaButton11.TabIndex = 17;
            this.gunaButton11.Text = "Clear";
            // 
            // gunaButton12
            // 
            this.gunaButton12.Animated = true;
            this.gunaButton12.AnimationHoverSpeed = 0.05F;
            this.gunaButton12.AnimationSpeed = 0.01F;
            this.gunaButton12.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton12.BorderColor = System.Drawing.Color.Black;
            this.gunaButton12.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton12.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton12.ForeColor = System.Drawing.Color.White;
            this.gunaButton12.Image = null;
            this.gunaButton12.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton12.Location = new System.Drawing.Point(22, 236);
            this.gunaButton12.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton12.Name = "gunaButton12";
            this.gunaButton12.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton12.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton12.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton12.OnHoverImage = null;
            this.gunaButton12.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton12.Size = new System.Drawing.Size(109, 46);
            this.gunaButton12.TabIndex = 18;
            this.gunaButton12.Text = "Clear";
            // 
            // gunaButton13
            // 
            this.gunaButton13.Animated = true;
            this.gunaButton13.AnimationHoverSpeed = 0.05F;
            this.gunaButton13.AnimationSpeed = 0.01F;
            this.gunaButton13.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton13.BorderColor = System.Drawing.Color.Black;
            this.gunaButton13.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton13.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton13.ForeColor = System.Drawing.Color.White;
            this.gunaButton13.Image = null;
            this.gunaButton13.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton13.Location = new System.Drawing.Point(403, 74);
            this.gunaButton13.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton13.Name = "gunaButton13";
            this.gunaButton13.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton13.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton13.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton13.OnHoverImage = null;
            this.gunaButton13.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton13.Size = new System.Drawing.Size(109, 46);
            this.gunaButton13.TabIndex = 19;
            this.gunaButton13.Text = "Clear";
            // 
            // gunaButton14
            // 
            this.gunaButton14.Animated = true;
            this.gunaButton14.AnimationHoverSpeed = 0.05F;
            this.gunaButton14.AnimationSpeed = 0.01F;
            this.gunaButton14.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton14.BorderColor = System.Drawing.Color.Black;
            this.gunaButton14.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton14.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton14.ForeColor = System.Drawing.Color.White;
            this.gunaButton14.Image = null;
            this.gunaButton14.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton14.Location = new System.Drawing.Point(403, 236);
            this.gunaButton14.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton14.Name = "gunaButton14";
            this.gunaButton14.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton14.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton14.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton14.OnHoverImage = null;
            this.gunaButton14.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton14.Size = new System.Drawing.Size(109, 46);
            this.gunaButton14.TabIndex = 20;
            this.gunaButton14.Text = "Clear";
            // 
            // gunaButton15
            // 
            this.gunaButton15.Animated = true;
            this.gunaButton15.AnimationHoverSpeed = 0.05F;
            this.gunaButton15.AnimationSpeed = 0.01F;
            this.gunaButton15.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton15.BorderColor = System.Drawing.Color.Black;
            this.gunaButton15.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton15.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton15.ForeColor = System.Drawing.Color.White;
            this.gunaButton15.Image = null;
            this.gunaButton15.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton15.Location = new System.Drawing.Point(403, 182);
            this.gunaButton15.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton15.Name = "gunaButton15";
            this.gunaButton15.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton15.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton15.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton15.OnHoverImage = null;
            this.gunaButton15.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton15.Size = new System.Drawing.Size(109, 46);
            this.gunaButton15.TabIndex = 21;
            this.gunaButton15.Text = "Clear";
            // 
            // gunaButton16
            // 
            this.gunaButton16.Animated = true;
            this.gunaButton16.AnimationHoverSpeed = 0.05F;
            this.gunaButton16.AnimationSpeed = 0.01F;
            this.gunaButton16.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton16.BorderColor = System.Drawing.Color.Black;
            this.gunaButton16.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton16.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton16.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton16.ForeColor = System.Drawing.Color.White;
            this.gunaButton16.Image = null;
            this.gunaButton16.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton16.Location = new System.Drawing.Point(403, 128);
            this.gunaButton16.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton16.Name = "gunaButton16";
            this.gunaButton16.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaButton16.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton16.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton16.OnHoverImage = null;
            this.gunaButton16.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton16.Size = new System.Drawing.Size(109, 46);
            this.gunaButton16.TabIndex = 22;
            this.gunaButton16.Text = "Clear";
            this.gunaButton16.Click += new System.EventHandler(this.gunaButton16_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.gunaButton17);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(543, 50);
            this.panel1.TabIndex = 23;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // gunaButton17
            // 
            this.gunaButton17.Animated = true;
            this.gunaButton17.AnimationHoverSpeed = 0.05F;
            this.gunaButton17.AnimationSpeed = 0.01F;
            this.gunaButton17.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gunaButton17.BorderColor = System.Drawing.Color.Black;
            this.gunaButton17.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton17.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton17.ForeColor = System.Drawing.Color.White;
            this.gunaButton17.Image = null;
            this.gunaButton17.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton17.Location = new System.Drawing.Point(505, 5);
            this.gunaButton17.Margin = new System.Windows.Forms.Padding(4);
            this.gunaButton17.Name = "gunaButton17";
            this.gunaButton17.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.gunaButton17.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton17.OnHoverForeColor = System.Drawing.Color.Wheat;
            this.gunaButton17.OnHoverImage = null;
            this.gunaButton17.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton17.Size = new System.Drawing.Size(32, 31);
            this.gunaButton17.TabIndex = 24;
            this.gunaButton17.Text = "X";
            this.gunaButton17.Click += new System.EventHandler(this.gunaButton17_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(170, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "KAZZIO\'s Script Hub";
            this.label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label1_MouseDown);
            this.label1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label1_MouseMove);
            // 
            // ScriptHub
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.ClientSize = new System.Drawing.Size(543, 295);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gunaButton16);
            this.Controls.Add(this.gunaButton15);
            this.Controls.Add(this.gunaButton14);
            this.Controls.Add(this.gunaButton13);
            this.Controls.Add(this.gunaButton12);
            this.Controls.Add(this.gunaButton11);
            this.Controls.Add(this.gunaButton10);
            this.Controls.Add(this.gunaButton9);
            this.Controls.Add(this.gunaButton8);
            this.Controls.Add(this.gunaButton7);
            this.Controls.Add(this.gunaButton6);
            this.Controls.Add(this.gunaButton5);
            this.Controls.Add(this.gunaButton3);
            this.Controls.Add(this.gunaButton2);
            this.Controls.Add(this.gunaButton1);
            this.Controls.Add(this.gunaButton4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ScriptHub";
            this.Text = "ScriptHub";
            this.Load += new System.EventHandler(this.ScriptHub_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaButton gunaButton4;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private Guna.UI.WinForms.GunaButton gunaButton5;
        private Guna.UI.WinForms.GunaButton gunaButton6;
        private Guna.UI.WinForms.GunaButton gunaButton7;
        private Guna.UI.WinForms.GunaButton gunaButton8;
        private Guna.UI.WinForms.GunaButton gunaButton9;
        private Guna.UI.WinForms.GunaButton gunaButton10;
        private Guna.UI.WinForms.GunaButton gunaButton11;
        private Guna.UI.WinForms.GunaButton gunaButton12;
        private Guna.UI.WinForms.GunaButton gunaButton13;
        private Guna.UI.WinForms.GunaButton gunaButton14;
        private Guna.UI.WinForms.GunaButton gunaButton15;
        private Guna.UI.WinForms.GunaButton gunaButton16;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaButton gunaButton17;
        private System.Windows.Forms.Label label1;
    }
}